import { Link } from '@material-ui/core'
import React from 'react'

export default function Profile() {

    return (
        <main>
            <div>
                <div className="head-title">
                    <div className="left">
                        <h1>Edit Profile</h1>
                        <ul className="breadcrumb">
                            <li>
                                <Link to="">Dashboard</Link>
                            </li>
                            <li><i className='bx bx-chevron-right' ></i></li>
                            <li>
                                <Link className="active" to="/">Edit Profile</Link>
                            </li>
                        </ul>
                    </div>
                    {/* <Link to="" className="btn-download">
                        <i class='bx bxs-user-check'></i>
                        <span className="text">Update Profile</span>
                    </Link> */}
                </div>
            </div>
            <div className="box-info-profile">
                <div className=''>
                    <h5 className='text-start'>Edit Profile Picture</h5>

                </div>

                <div className=''>
                    <h5 className='text-start'>Personal Info</h5>
                    <form >
                        <div className='row'>
                            <div className="form-group col-6">
                                <label for="exampleInputEmail1" className='text-start'>First Name</label>
                                <input type="text" className="form-control" id="exampleInputEmail1" placeholder="enter first name" />
                            </div>
                            <div className="form-group col-6">
                                <label for="exampleInputEmail1" className=''>Last Name</label>
                                <input type="text" className="form-control" id="exampleInputEmail1" placeholder="enter last name" />
                            </div>
                            <div className="form-group col-6">
                                <label for="exampleInputEmail1" className=''>Email address</label>
                                <input type="email" className="form-control" id="exampleInputEmail1" placeholder="Enter email" />
                            </div>
                            <div className="form-group col-6">
                                <label for="exampleInputEmail1" className=''>Birthdate</label>
                                <input type="date" className="form-control" id="exampleInputEmail1" placeholder="Enter email" />
                            </div>
                        </div>
                        <button type="submit" className="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </main>


    )
}
