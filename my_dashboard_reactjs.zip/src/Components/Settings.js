import React from 'react'

export default function Settings() {
  return (
    <div></div>
    // <div style={{textAlign:'center'}}>Settings</div>
  )
}
