import React, { useState } from 'react'
import '../App.css';
import { Link } from 'react-router-dom';

export default function Sidebar(props) {

  const { route } = props
  const xxx = () => {
    const allSideMenu = document.querySelectorAll(".side-menu li");
    // console.log(allSideMenu)
    allSideMenu.forEach(i => {
      i.addEventListener('click', () => {
        allSideMenu.forEach(i => {
          i.classList.remove('active');
        })
        i.classList.add("active");
      })
    })
  }
  const [WIdth, setWIdth] = useState(window.innerWidth)
  // console.log(window.innerWidth)
  React.useEffect(() => {
    window.addEventListener("resize", () => {
      setWIdth(window.innerWidth)
    })

    const sidebar = document.getElementById('sidebar');

    const searchButton = document.querySelector('#content nav form .form-input button')
    const searchButtonIcon = document.querySelector('#content nav form .form-input button .bx')
    // console.log(searchButton)
    const searchForm = document.querySelector('#content nav form')
    // console.log(searchForm)
    searchButton.addEventListener('click', function (e) {
      if (WIdth < 576) {
        e.preventDefault();
        searchForm.classList.add('show');
        if (searchForm.classList.contains('show')) {
          searchButtonIcon.classList.replace('bx-search-alt', 'bx-search-alt');
        }
        else {
          searchButtonIcon.classList.replace('bx-search-alt', 'bx-search-alt');
        }
      }
    })

    if (WIdth < 768) {
      sidebar.classList.add('hide');
    } else {
      sidebar.classList.remove('hide');
    }
    xxx()
  }, [WIdth])


  // Show and hide sidebar
  const MenuSide = () => {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('hide');
  }

  return (
    <div>
      <section id='sidebar'>
        <Link to="/" className="brand">
          <span className="icon ">
            <i className='bx bx-leaf' ></i>
            <span className="text ctext sildeToogle">Admin</span>
          </span>
        </Link>


        <ul className="side-menu top">
          {/* 1. Dashboard  */}
          <li className="active">
            <Link to="/">
              <i className="bx bxs-dashboard"></i>
              <span className="text">Dashboard</span>
            </Link>
          </li>

          {/*  2. Products   */}
          <li>
            <Link to="/products">
              <i className='bx bx-spreadsheet'></i>
              <span className="text">Products</span>
            </Link>
          </li>

          {/* 3. Categories  */}
          <li>
            <Link to="/categories">
              <i className='bx bxs-category-alt' ></i>
              <span className="text">Categories</span>
            </Link>
          </li>

          {/* 4. Posts  */}
          <li>
            <Link to="/posts">
              <i className='bx bxs-book-add' ></i>
              <span className="text">Posts</span>
            </Link>
          </li>

          {/*  5. Users  */}
          <li>
            <Link to="/users">
              <i className='bx bxs-user-circle' ></i>
              <span className="text">Users</span>
            </Link>
          </li>

          {/* 6. Redirection Other Blog  */}
          <li>
            <Link to="/redirects-blog">
              <i class='bx bx-transfer' ></i>
              <span className="text">Redirection Other Blog</span>
            </Link>
          </li>

          {/* 7. Languages  */}
          <li>
            <Link to="/languages">
              <i className='bx bxl-blogger' ></i>
              <span className="text">Languages</span>
            </Link>
          </li>
        </ul>


        <ul className="side-menu">
          {/* 1. Settings  */}
          <li>
            <Link to="/settings">
              <i className='bx bxs-cog' ></i>
              <span className="text">Settings</span>
            </Link>
          </li>

          {/* 2. Products   */}
          <li>
            <Link to="/">
              <i className='bx bx-log-out' ></i>
              <span className="text">Logout</span>
            </Link>
          </li>
        </ul>
      </section>



      {/* Content */}
      <section id='content'>
        {/* Navbar */}
        <nav>

          <i className='bx bx-menu notification' onClick={MenuSide}></i>
          <Link to="/" className="nav-link"></Link>
          <form>
            <div className="form-input">
              <input type="search" placeholder='search...' />
              <button type='submit' className='search-btn'><i className='bx bx-search-alt' ></i></button>
            </div>
          </form>
          <Link to="/" className="notification"><i className='bx bxs-bell-ring' ></i></Link>
          <Link to="/" className='notification'><i className='bx bxs-user-circle' ></i></Link>

        </nav>
        {/* Navbar */}
        {route}
      </section>

    </div>
  )
}
