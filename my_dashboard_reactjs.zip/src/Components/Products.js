import React from 'react'
import { Link } from 'react-browser-router'

export default function Products() {
  return (

    <main>
      <div className="head-title">
        <div className="left">
          <h1>Products</h1>
          <ul className="breadcrumb">
            <li>
              <Link to="">Dashboard</Link>
            </li>
            <li><i className='bx bx-chevron-right' ></i></li>
            <li>
              <Link className="active" to="/">Products</Link>
            </li>
          </ul>
        </div>
        <Link to="" className="btn-download">
          <i class='bx bxs-add-to-queue'></i>
          <span className="text">Add New Product</span>
        </Link>

      </div>
    </main>
  )
}
