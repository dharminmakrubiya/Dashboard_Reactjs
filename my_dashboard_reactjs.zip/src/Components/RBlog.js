import React from 'react'
import { Link } from 'react-browser-router'

export default function redirectBlog() {
  return (
    <main>
      <div className="head-title">
        <div className="left">
          <h1>Redirection Other Blog</h1>
          <ul className="breadcrumb">
            <li>
              <Link to="">Dashboard</Link>
            </li>
            <li><i className='bx bx-chevron-right' ></i></li>
            <li>
              <Link className="active" to="/">Blog</Link>
            </li>
          </ul>
        </div>
        <Link to="" className="btn-download">
          <i class='bx bxs-add-to-queue'></i>
          <span className="text">Add New Redirection</span>
        </Link>

      </div>
    </main>
  )
}
