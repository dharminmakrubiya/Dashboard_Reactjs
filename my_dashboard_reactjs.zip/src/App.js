// import logo from './logo.svg';
import './App.css';
import Products from './Components/Products';
import Sidebar from './Components/Sidebar';
import Dashboard from './Components/Dashboard';
import Categories from './Components/Categories';
import Posts from './Components/Posts';
import Users from './Components/Users';
import RBlog from './Components/RBlog';
import Language from './Components/Language';

import { BrowserRouter, BrowserRouter as Router, Redirect, Switch, Route, Link, Routes } from 'react-router-dom';



function App() {

  const route = (<>
    <Routes>

      <Route path='/' element={<Dashboard />} />
      <Route path='/products' element={<Products />} />
      <Route path='/categories' element={<Categories />} />
      <Route path='/posts' element={<Posts />} />
      <Route path='/users' element={<Users />} />
      <Route path='/redirects-blog' element={<RBlog />} />
      <Route path='/languages' element={<Language />} />

    </Routes>

  </>)

  return (
    <BrowserRouter>
      <div className="App">
        <Sidebar route={route} />
      </div>


    </BrowserRouter>

  );
}

export default App;
