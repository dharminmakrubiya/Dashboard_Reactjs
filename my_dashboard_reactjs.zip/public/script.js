const allSideMenu = document.querySelectorAll('#sidebar .side-menu.top li ');
console.log(allSideMenu)

// const xyz = allSideMenu.querySelectorAll('.side-menu .top li')
// console.log('xyz',xyz)

allSideMenu.forEach(item=> {
    console.log(item)
    const li = item;


    item.addEventListener('click',function () {
        li.classList.add('active');
    })
});